# 3D（ThreeDimensions）

## Blender
### Blender快捷键汇总（Mac）
- 切换视图：~ 键
- 四视图：ctl + opt + q

### 归零操作
- opt + G：坐标归零
- opt + R：旋转归零
- opt + S：缩放归零

### 全局移动
- 选中物体，按 G 键
- 按 X、Y、Z ，可按照对应方向移动

### 复制
- Shift + D：复制后直接进入抓取模式


### 编辑模型
使用 Tab 键进入编辑模型
- 可在左上方选择编辑：点、线、面
- 加选：按住shift
- 减选：按住ctl
- 全选：a
